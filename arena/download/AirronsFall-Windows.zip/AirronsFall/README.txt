Airron's Fall for Windows
=========================

Double-click "Airron's Fall.exe" to play. Your progress (gold, rites, unlocks,
settings) is saved on this computer and will still be there the next time you
open the game.

Windows may show a SmartScreen warning that this is an "unrecognized app"
because the download is not code-signed. Choose More info, then Run anyway.

The game uses Microsoft Edge WebView2, which is already on Windows 11 and on
most up-to-date Windows 10 PCs. If the window does not open, install the free
WebView2 Evergreen Runtime from Microsoft:
https://developer.microsoft.com/en-us/microsoft-edge/webview2/

You can also play in a browser at https://airronkennedy.com/arena/
